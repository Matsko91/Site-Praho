document.addEventListener("mousemove", (e) => {
    const bg = document.querySelector('.neon-bg');
    bg.style.transform = `translate(${e.clientX / 30}px, ${e.clientY / 30}px)`;
});
